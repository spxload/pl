(function () {
	'use strict';
  
	Lampa.Utils.putScriptAsync(['https://lampame.github.io/main/nc/nc.js'], function () { });
  
  })();
