# Migration & Compatibility

Track changes in Lampa plugin APIs and recommendations.

- Check for deprecations in `Lampa` namespaces you use.
- Feature-detect and fallback.
- Maintain changelog in your repo and note required app versions.
