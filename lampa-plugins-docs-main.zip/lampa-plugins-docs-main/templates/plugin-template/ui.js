/* UI helpers for My Lampa Plugin */

export function renderButton(label){
  return $('<div class="myplugin-btn">'+label+'</div>')
}
