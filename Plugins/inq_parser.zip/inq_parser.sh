#!/usr/bin/bash
cd /opt/inq_parser
node /opt/inq_parser/inq_parser.js
cp /opt/inq_parser/inq_parser.json /home/lampac/wwwroot/inq_parser.json
